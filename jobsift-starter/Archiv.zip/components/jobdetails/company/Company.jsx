import React from 'react'
import { View, Text } from 'react-native'

import styles from './company.style'

const Company = () => {
  return (
    <View>
      <Text>Company</Text>
    </View>
  )
}

export default Company