import React from 'react'
import { View, Text } from 'react-native'

import styles from './popularjobs.style'

const Popularjobs = () => {
  return (
    <View>
      <Text>Popularjobs</Text>
    </View>
  )
}

export default Popularjobs