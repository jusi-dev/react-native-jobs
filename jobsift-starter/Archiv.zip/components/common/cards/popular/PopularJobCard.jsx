import React from 'react'
import { View, Text } from 'react-native'

import styles from './popularjobcard.style'

const PopularJobCard = () => {
  return (
    <View>
      <Text>PopularJobCard</Text>
    </View>
  )
}

export default PopularJobCard