import profile from "../assets/images/kemal.jpg";

export default {
  profile,
};
